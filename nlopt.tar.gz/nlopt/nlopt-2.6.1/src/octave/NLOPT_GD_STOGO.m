% NLOPT_GD_STOGO: StoGO (global, derivative-based)
%
% See nlopt_minimize for more information.
function val = NLOPT_GD_STOGO
  val = 8;
